
public class MidTerm03 {
	public int sum(int x, int y, int z){
		return x+y+z;
	}
	public int sum(int x, int y){
		return x+y;
	}
	
}
