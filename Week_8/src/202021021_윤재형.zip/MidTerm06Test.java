
public class MidTerm06Test {

	public static void main(String[] args) {
		MidTerm06 obj= new MidTerm06();
		Flyable a = obj;
		Drivable b = obj;
		a.fly();
		b.drive();
	}

}
