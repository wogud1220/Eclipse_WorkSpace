
public class MidTerm07Test {

	public static void main(String[] args) {
		MidTerm07 obj=new MidTerm07();
		System.out.println(obj);

	}

}
