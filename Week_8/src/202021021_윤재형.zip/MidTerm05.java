
public class MidTerm05 {

	//Animal Animal = new Animal();

	void sound() {
		System.out.println("Animal 클래스의 sound()");
	}

	

	
	

}
