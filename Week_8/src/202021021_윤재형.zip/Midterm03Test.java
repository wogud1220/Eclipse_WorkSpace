

public class Midterm03Test {

	public static void main(String[] args) {
		MidTerm03 obj=new MidTerm03();
		obj.sum(10,20,30);
		obj.sum(10,20);
		System.out.println(obj.sum(10,20,30));
		System.out.println(obj.sum(10,20));
	}

}
