
public class Cat extends MidTerm05 {

	void sound() { // 부모의 것 오버라이딩
		System.out.println("야옹");
	}

}
