interface Animal{
	public void walk();
	public void fly();
	public void sing();
}
public class MidTerm07 implements Animal{
	public void walk() {
		System.out.println("Bird는 걸을 수 있음");
	}
	public void fly() {
		System.out.println("날 수 있음,");
	}
	public void sing() {
		System.out.println("노래할 수 있음,");
	}
	public String ToString() {
		return 
	}

}
